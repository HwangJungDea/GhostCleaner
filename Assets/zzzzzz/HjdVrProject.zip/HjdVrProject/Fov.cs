using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fov : MonoBehaviour
{
    public GameObject S_rayPoint;

    bool[] ghosts;

    void Start()
    {
        ghosts = new bool[2];
    }

    // Update is called once per frame
    void Update()
    {

    }
    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "Ghost")
        {
            Vector3 TriggerTarget_dir = other.transform.position - S_rayPoint.transform.position;
            TriggerTarget_dir.Normalize();
            Ray ray = new Ray(S_rayPoint.transform.position, TriggerTarget_dir);

            RaycastHit hitInfo;
            if (Physics.Raycast(ray, out hitInfo))
            {
                Debug.DrawRay(ray.origin, ray.direction, Color.green);

                MeshRenderer ren = other.transform.GetComponent<MeshRenderer>(); //�ڱⲨ
                //���̸� �i�� �� ���� ������Ʈ���� �Ÿ� ���
                if (hitInfo.transform.gameObject.tag == "Ghost")
                {
                    ren.enabled = false;
                }
                else
                {
                    ren.enabled = true;
                }


                //float hitinfoDis = Vector3.Distance(S_rayPoint.transform.position, hitInfo.transform.position);

                //if (targetDis == hitinfoDis)//(targetDis == hitinfoDis)
                //{
                //    enemyMR.enabled = true;
                //    other = null;
                //}
                //else
                //{
                //    enemyMR.enabled = false;
                //    other = null;
                //}

            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        MeshRenderer ren = other.transform.GetComponent<MeshRenderer>();
        if (ren != null && ren.enabled == false)
        {
            ren.enabled = true;
        }
    }


}
