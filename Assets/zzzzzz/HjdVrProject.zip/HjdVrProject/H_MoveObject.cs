using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class H_MoveObject : MonoBehaviour
{
    //public static H_MoveObject instance;

    //private void Awake()
    //{
    //    instance = this;
    //}

    Vector3 origin_tr;
    Vector3 destination_tr;

    Quaternion origin_ro;
    Quaternion destination_ro;


    public bool openObject = false;
    public bool closeObject = false;


    public enum SpawnType
    {
        �����,
        ��������,
        ū����,
    }


    public SpawnType spawnType = SpawnType.�����;
    void Start()
    {
        switch (spawnType)
        {
            case SpawnType.�����:
                origin_ro = transform.rotation;
                destination_ro = transform.rotation;
                destination_ro = transform.rotation * Quaternion.Euler(new Vector3(0, -160, 0));
                break;

            case SpawnType.��������:
                origin_tr = transform.position;
                destination_tr = transform.position + transform.forward;
                break;

            case SpawnType.ū����:
                origin_tr = transform.position;
                destination_tr = transform.position + transform.forward;
                break;
        }

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1")) //�÷��̾� �Է°� (������)
        {
            openObject = true;
            closeObject = false;
        }

        if (Input.GetButtonUp("Fire1"))  //�÷��̾� �Է°� (����)
        {
            openObject = false;
            closeObject = true;
        }

        switch (spawnType)
        {
            case SpawnType.�����: Update�����(); break;
            case SpawnType.��������: Update��������(); break;
            case SpawnType.ū����: Updateū����(); break;
        }
    }
    private void Update�����()
    {
        if (openObject == true)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation, destination_ro, Time.deltaTime * 5);
        }

        if (closeObject == true)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation, origin_ro, Time.deltaTime * 5);
        }
    }

    private void Updateū����()
    {
        if (openObject == true)
        {
            transform.position = Vector3.Lerp(transform.position, destination_tr, Time.deltaTime * 5);
            if (Vector3.Distance(transform.position, destination_tr) < 0.1f)
            {
                openObject = false;
            }
        }

        if (closeObject == true)
        {
            transform.position = Vector3.Lerp(transform.position, origin_tr, Time.deltaTime * 5);
            if (Vector3.Distance(transform.position, destination_tr) < 0.1f)
            {
                closeObject = false;
            }
        }
    }

    private void Update��������()
    {
        if (openObject == true)
        {
            transform.position = Vector3.Lerp(transform.position, destination_tr, Time.deltaTime * 5);
            if (Vector3.Distance(transform.position, destination_tr) < 0.1f)
            {
                openObject = false;
            }
        }

        if (closeObject == true)
        {
            transform.position = Vector3.Lerp(transform.position, origin_tr, Time.deltaTime * 5);
            if (Vector3.Distance(transform.position, destination_tr) < 0.1f)
            {
                closeObject = false;
            }
        }
    }
}
